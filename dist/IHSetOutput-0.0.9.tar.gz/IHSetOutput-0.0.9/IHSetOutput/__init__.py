""" Template """

__version__ = "0.0.9"
__author__ = "Lucas de Freitas Pereira"
__author_email__ = "lucas.defreitas@unican.es"
__description__ = "IH-SET output module"

from . import output
