# IHSetOutput

Generate output dataset for IH-SET software

## Installation and use

To install this module use:

```sh
pip install git+git+https://github.com/IHCantabria/IHSetOutput.git
```


Documentation is available at https://ihcantabria.github.io/IHSetOutput

